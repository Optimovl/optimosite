<?= json_encode($exception); ?>
