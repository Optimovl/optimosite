<?php

	/** Класс пользовательских методов административной панели */
	class BlogsCustomAdmin {

		/** @var blogs20 $module */
		public $module;
	}
