<?php

$C_LANG = Array();

$C_LANG['module_name'] = "Формы Lite";
$C_LANG['module_title'] = "Формы Lite";
$C_LANG['module_describtion'] = <<<DESC

Дает возможность создавать формы обратной связи.<br />
E-mail можно ввести в систему, и он будет недоступен спам-роботам.

DESC;

$C_LANG['posted'] = "Сообщение отправлено";
$C_LANG['send']   = "Сообщение отправлено";

$LANG_EXPORT = Array();

$LANG_EXPORT['formslite_thank_you'] = "Спасибо за интерес. Мы ответим на ваше письмо в ближайшее время.";

?>