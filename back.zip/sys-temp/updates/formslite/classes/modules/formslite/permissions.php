<?php
$permissions = Array(
	'view' => Array('send', 'posted'),
	'admin'  => array('docs', 'temptaes', 'template_add', 'template_delete', 'template_edit', 'del')
);
?>
