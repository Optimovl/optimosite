<?php
$i18n = Array(
    'module-formslite' => 'Формы Lite',

	'header-formslite-docs' => 'Документация',
	'header-formslite-templates' => 'Шаблоны писем',
	'header-formslite-config' => 'Настройки',
	'header-formslite-template_add'=> 'Добавление шаблона',
	'header-formslite-template_edit' => 'Редактирование шаблона',

	'option-email_to' => 'E-mail получателя',
	'option-name_to' => 'Имя получателя',

	'label-template-add'    => 'Добавить шаблон',

	'label-form'            => 'Форма',
	'label-name'            => 'Название формы',

	'perms-formslite-view' => 'Использование модуля',
	'perms-formslite-admin' => 'Администрирование модуля',

	'error-no_recipients'=> 'Укажите E-mail получателя в настройках модуля'
);
?>
