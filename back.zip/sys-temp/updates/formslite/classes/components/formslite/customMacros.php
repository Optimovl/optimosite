<?php
	/**
	 * Класс пользовательских макросов
	 */
	class FormsliteCustomMacros {
		/**
		 * @var news $module
		 */
		public $module;
	}
?>