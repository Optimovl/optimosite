<?php
	/**
	 * Класс пользовательских методов административной панели
	 */
	class FormsliteCustomAdmin {
		/**
		 * @var news $module
		 */
		public $module;
	}
?>