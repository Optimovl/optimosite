<?php
	/**
	 * Класс пользовательских методов для всех режимов
	 */
	class FormsliteCustomCommon {
		/**
		 * @var news $module
		 */
		public $module;
	}
?>