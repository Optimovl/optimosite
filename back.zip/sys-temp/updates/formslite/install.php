<?php

$INFO = Array();
$INFO['version'] = "1.0";

$INFO['name'] = "formslite";
$INFO['title'] = "Формы Lite";
$INFO['filename'] = "modules/formslite/class.php";
$INFO['config'] = "1";
$INFO['ico'] = "ico_formslite";
$INFO['default_method_admin'] = "templates";
$INFO['is_indexed'] = "1";
$INFO['per_page'] = "10";

$INFO['func_perms'] = "";
$INFO['func_perms/view'] = "Использование модуля";
$INFO['func_perms/admin']  = "Основные права на управление модулем";

