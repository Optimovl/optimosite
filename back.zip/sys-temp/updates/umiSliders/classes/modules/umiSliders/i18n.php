<?php
	/** Языковые константы для русской версии */
	$i18n = [
		'module-umiSliders' => 'Слайдеры',
		'header-umiSliders-getSliders' => 'Слайдеры',
	];
