<?php
	/** Языковые константы для английской версии */
	$i18n = [
		'module-umiSliders' => 'Sliders',
		'header-umiSliders-getSliders' => 'Sliders',
	];