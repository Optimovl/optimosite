<?php

	/** @var array $C_LANG языковые константы для английской версии */
	$C_LANG = [
		'module_name' => 'Sliders'
	];
