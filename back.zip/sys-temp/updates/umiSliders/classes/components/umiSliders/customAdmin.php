<?php

	/** Класс пользовательских методов административной панели */
	class UmiSlidersCustomAdmin implements iModulePart {

		use tModulePart;
	}
