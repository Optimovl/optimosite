<?php

	/** Класс обработчиков событий */
	class UmiSlidersHandlers implements iModulePart {

		use tModulePart;
	}
