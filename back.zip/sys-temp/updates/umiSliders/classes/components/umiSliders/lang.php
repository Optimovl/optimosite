<?php

	/** @var array $C_LANG языковые константы для русской версии */
	$C_LANG = [
		'module_name' => 'Слайдеры'
	];
