<?php

	/** Класс пользовательских макросов */
	class UmiSlidersCustomMacros implements iModulePart {

		use tModulePart;
	}
