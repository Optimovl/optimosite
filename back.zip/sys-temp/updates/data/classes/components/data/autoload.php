<?php

	$classes = [
		'UmiCms\Classes\Components\Data\FormSaver' => [
			__DIR__ . '/Classes/FormSaver.php'
		],

		'UmiCms\Classes\Components\Data\iFormSaver' => [
			__DIR__ . '/Classes/iFormSaver.php'
		],
	];