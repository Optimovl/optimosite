<?php

	/** Класс пользовательских методов административной панели */
	class DataCustomAdmin {

		/** @var data $module */
		public $module;

	}
