<?php

	/** Класс пользовательских макросов */
	class DataCustomMacros {

		/** @var data $module */
		public $module;

	}
