<?php

	/** Языковые константы для английской версии */
	$C_LANG = [];
	$C_LANG['module_name'] = 'Reservation';
	$C_LANG['module_title'] = 'Version control';
	$C_LANG['config'] = 'Module settings';
	$C_LANG['bfilesystem'] = 'Backup file structure';
	$C_LANG['bsettings'] = 'Backup settings';

	$LANG_EXPORT = [];
	$LANG_EXPORT['backup_nodata'] = 'The database contains no information about changes in this section.';

