<?php

	/** Класс пользовательских методов административной панели */
	class BackupCustomAdmin {

		/** @var backup $module */
		public $module;

	}
