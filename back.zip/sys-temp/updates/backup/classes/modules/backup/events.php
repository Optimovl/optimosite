<?php
	new umiEventListener('cron', 'backup', 'onCronCleanChangesHistory');
?>
