<?php
$C_LANG = Array();

$C_LANG['module_name'] = "Резервирование";

$C_LANG['module_title'] = "Контроль версий";

$C_LANG['config'] = "Настройка модуля";
$C_LANG['bfilesystem'] = "Бэкап файловой структуры";
$C_LANG['bsettings'] = "Бэкап настроек";


$LANG_EXPORT = Array();
$LANG_EXPORT['backup_nodata'] = "В базе данных нет информации об изменениях этого раздела.";
//$LANG_EXPORT['backup_nodata'] = "No backuped data in database for this element.";
?>
