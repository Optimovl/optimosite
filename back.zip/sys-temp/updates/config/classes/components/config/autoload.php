<?php

	$classes = [
		'UmiCms\Classes\Components\Config\Watermark\AdminSettingsManager' => [
			__DIR__ . '/classes/Watermark/AdminSettingsManager.php'
		],
		'UmiCms\Classes\Components\Config\Watermark\iAdminSettingsManager' => [
			__DIR__ . '/classes/Watermark/iAdminSettingsManager.php'
		],
		'UmiCms\Classes\Components\Config\Captcha\AdminSettingsManager' => [
			__DIR__ . '/classes/Captcha/AdminSettingsManager.php'
		],
		'UmiCms\Classes\Components\Config\Captcha\iAdminSettingsManager' => [
			__DIR__ . '/classes/Captcha/iAdminSettingsManager.php'
		],
		'UmiCms\Classes\Components\Config\Mail\AdminSettingsManager' => [
			__DIR__ . '/classes/Mail/AdminSettingsManager.php'
		],
		'UmiCms\Classes\Components\Config\Mail\iAdminSettingsManager' => [
			__DIR__ . '/classes/Mail/iAdminSettingsManager.php'
		]
	];
