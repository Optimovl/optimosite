<?php

	/** Класс пользовательских макросов */
	class ConfigCustomMacros {

		/** @var config $module */
		public $module;
	}
