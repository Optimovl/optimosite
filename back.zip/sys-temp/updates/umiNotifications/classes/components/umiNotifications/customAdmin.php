<?php

	/** Класс пользовательских методов административной панели */
	class umiNotificationsCustomAdmin {

		/** @var umiNotifications $module */
		public $module;

	}
