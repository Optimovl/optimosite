<?php

	/** Языковые константы для английской версии */

	$C_LANG = [
		'module_name' => 'Notifications'
	];
