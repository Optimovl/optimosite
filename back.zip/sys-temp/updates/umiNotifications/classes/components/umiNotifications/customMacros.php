<?php

	/** Класс пользовательских макросов */
	class umiNotificationsCustomMacros {

		/** @var umiNotifications $module */
		public $module;
	}
