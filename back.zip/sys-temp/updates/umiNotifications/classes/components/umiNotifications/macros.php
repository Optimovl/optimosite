<?php

	/** Класс макросов, то есть методов, доступных в шаблоне */
	class umiNotificationsMacros {

		/** @var umiNotifications $module */
		public $module;

	}
