<?php

	/** Группы прав на функционал модуля */
	$permissions = [
		/** Административные права */
		'admin' => [
			'notifications',
			'edit',
			'flushdatasetconfiguration'
		]
	];
