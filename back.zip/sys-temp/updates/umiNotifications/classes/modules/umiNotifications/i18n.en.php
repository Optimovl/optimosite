<?php
	/** Языковые константы для английской версии */
	$i18n = [
		'module-umiNotifications' => 'Notifications',
		'header-umiNotifications-notifications' => 'Notification List'
	];
