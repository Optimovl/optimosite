<?php
	/** Языковые константы для русской версии */
	$i18n = [
		'module-umiNotifications' => 'Шаблоны уведомлений',
		'header-umiNotifications-notifications' => 'Уведомления'
	];
