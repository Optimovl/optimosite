<?php

/*	define("SQL_QUERY_DEBUG", "1");
	define("DEBUG_SQL_SELECTOR", 1);
*/


	$paramcpu_page=explode ("/", $_REQUEST['path']);
    $cpu_page=$paramcpu_page[count($paramcpu_page)-2];
	if(strpos($cpu_page, 'page_')!==false){
		$p=(int)str_replace ('page_', '', $cpu_page)-1;
		$_REQUEST['p']=$p;
		$_GET['p']=$p;
		$path=str_replace ($cpu_page.'/', '', $_REQUEST['path']);
		$_REQUEST['path']=$path;
		$_GET['path']=$path;
		$_SERVER['REDIRECT_URL']=str_replace ($cpu_page.'/', '', $_SERVER['REDIRECT_URL']);
		$_SERVER['REQUEST_URI']=str_replace ($cpu_page.'/', '', $_SERVER['REQUEST_URI']);
	}
	define("CURRENT_WORKING_DIR", str_replace("\\", "/", $dirname = dirname(__FILE__)));
	require CURRENT_WORKING_DIR . '/libs/root-src/index.php';


?>