<?php
    class admin_numpages {

        public function __construct($module) {
        	$this->module = $module;

            $commonTabs = $this->module->getCommonTabs();

            if($commonTabs) {
                $commonTabs->add('numpages');
            }
        }

        public function numpages() {
            $regedit = regedit::getInstance();

            $params = array(
				"numpages" => array(
					"boolean:numpages" => NULL,
				)
			);
			$mode = getRequest("param0");

			if($mode == "do") {
				if (file_exists(CURRENT_WORKING_DIR.'/.htaccess')) {

					$params = $this->module->expectParams($params);
	                $numpages = $params['numpages']['boolean:numpages'];

	                $content = file_get_contents(CURRENT_WORKING_DIR.'/.htaccess');
					foreach(explode("\n", $content) as $ht_key=>$ht_line) {
						$line=trim($ht_line);
						if($numpages==1){
							if (preg_match('|(.*?) index.php\?path=(.*?)|i', $line)) {
	                           $line=str_replace('index.php', 'cpuindex.php', $line);
	                        	$numpages=1;
							}elseif (preg_match('|(.*?) cpuindex.php\?path=(.*?)|i', $line)) {
                                $numpages=1;
							}
							
						}else{
							if (preg_match('|(.*?) cpuindex.php\?path=(.*?)|i', $line)) {
	                           $line=str_replace('cpuindex.php', 'index.php', $line);
	                        	$close_site=0;
							}elseif (preg_match('|(.*?) cpuindex.php\?path=(.*?)|i', $line)) {
                                $close_site=0;
							}
						}
						$ht_array[] = $line;


					}
					$content = implode("\r\n", $ht_array)."\r\n";
					file_put_contents(CURRENT_WORKING_DIR.'/.htaccess', $content);
					$regedit->setVar("//numpages/numpages", $numpages);
				}



				$this->module->chooseRedirect();
			}

			$params['numpages']['boolean:numpages'] = $regedit->getVal("//numpages/numpages");

			$this->module->setDataType("settings");
			$this->module->setActionType("modify");

			$data = $this->module->prepareData($params, "settings");

			$this->module->setData($data);
			$this->module->doData();
        }
    }
?>