<?php

$i18n = Array(
	"header-seo-numpages" => "ЧПУ numpages",
	'option-numpages' => "Активировать ЧПУ numpages",
	'group-numpages' => "Общие настройки расширения"
	);

?>