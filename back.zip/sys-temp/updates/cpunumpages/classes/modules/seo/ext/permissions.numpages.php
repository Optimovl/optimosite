<?
	$permissions = array(
		'seo' => array('numpages')
	);
?>