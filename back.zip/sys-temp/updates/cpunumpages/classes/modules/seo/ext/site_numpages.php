<?
	abstract class site_numpages {
        public function numpages($total = 0, $per_page = 0, $template = "default", $varName = "p", $max_pages = false) {
			$varName = "p";
			if(!$max_pages) (int) $max_pages = false;

			$regedit = regedit::getInstance();
			$page=umiPagenum::generateNumPage($total, $per_page, $template, $varName, $max_pages);
			if($regedit->getVal("//numpages/numpages")==1){
				foreach($page['void:pages'] as $key=>$val){
					$link=str_replace('?p='.$page['void:pages'][$key]['attribute:page-num'].'&', 'page_'.$page['void:pages'][$key]['node:num'].'/?', $page['void:pages'][$key]['attribute:link']);	            	$link=str_replace('?p='.$page['void:pages'][$key]['attribute:page-num'], 'page_'.$page['void:pages'][$key]['node:num'].'/', $link);
	            	$page['void:pages'][$key]['attribute:link']=$_SERVER['REDIRECT_URL'].$link;
	            	$page['void:pages'][$key]['attribute:page-num']=$page['void:pages'][$key]['node:num'];				}
				$page['items']['nodes:item']=$page['void:pages'];
				if(is_array($page['toend_link'])){					$link=str_replace('?p='.$page['toend_link']['attribute:page-num'].'&', 'page_'.($page['toend_link']['attribute:page-num']+1).'/?', $page['toend_link']['node:value']);
	            	$link=str_replace('?p='.$page['toend_link']['attribute:page-num'], 'page_'.($page['toend_link']['attribute:page-num']+1).'/', $link);
	            	$page['toend_link']['attribute:page-num']++;
					$page['toend_link']['node:value']=$_SERVER['REDIRECT_URL'].$link;				}
				if(is_array($page['tonext_link'])){
					$link=str_replace('?p='.$page['tonext_link']['attribute:page-num'].'&', 'page_'.($page['tonext_link']['attribute:page-num']+1).'/?', $page['tonext_link']['node:value']);
	            	$link=str_replace('?p='.$page['tonext_link']['attribute:page-num'], 'page_'.($page['tonext_link']['attribute:page-num']+1).'/', $link);
	            	$page['tonext_link']['attribute:page-num']++;
					$page['tonext_link']['node:value']=$_SERVER['REDIRECT_URL'].$link;
				}
				if(is_array($page['tobegin_link'])){
					$link=str_replace('?p='.$page['tobegin_link']['attribute:page-num'].'&', 'page_'.($page['tobegin_link']['attribute:page-num']+1).'/?', $page['tobegin_link']['node:value']);
	            	$link=str_replace('?p='.$page['tobegin_link']['attribute:page-num'], 'page_'.($page['tobegin_link']['attribute:page-num']+1).'/', $link);
	            	$page['tobegin_link']['attribute:page-num']++;
					$page['tobegin_link']['node:value']=$_SERVER['REDIRECT_URL'].$link;
				}
				if(is_array($page['toprev_link'])){
					$link=str_replace('?p='.$page['toprev_link']['attribute:page-num'].'&', 'page_'.($page['toprev_link']['attribute:page-num']+1).'/?', $page['toprev_link']['node:value']);
	            	$link=str_replace('?p='.$page['toprev_link']['attribute:page-num'], 'page_'.($page['toprev_link']['attribute:page-num']+1).'/', $link);
	            	$page['toprev_link']['attribute:page-num']++;
					$page['toprev_link']['node:value']=$_SERVER['REDIRECT_URL'].$link;
				}
				$page['current-page']++;
			}
			return $page;
		}
    }
?>