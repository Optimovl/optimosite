<?php
    abstract class admin_numpages {

        public function onImplement() {
            if(cmsController::getInstance()->getCurrentMode() != 'admin')
            return;

            $commonTabs = $this->getCommonTabs();

            if($commonTabs) {
                $commonTabs->add('numpages');
            }
        }

        public function numpages() {
            $regedit = regedit::getInstance();

            $params = array(
				"numpages" => array(
					"boolean:numpages" => NULL,
				)
			);
			$mode = getRequest("param0");

			if($mode == "do") {
				if (file_exists(CURRENT_WORKING_DIR.'/.htaccess')) {

					$params = $this->expectParams($params);
	                $numpages = $params['numpages']['boolean:numpages'];

					$content = file_get_contents(CURRENT_WORKING_DIR.'/.htaccess');
					if($numpages==1){
							if (preg_match('|(.*?) index.php\?path=(.*?)|i', $line)) {
	                           $line=str_replace('index.php', 'cpuindex.php', $line);
	                        	$numpages=1;
							}elseif (preg_match('|(.*?) cpuindex.php\?path=(.*?)|i', $line)) {
                                $numpages=1;
							}
							
						}else{
							if (preg_match('|(.*?) cpuindex.php\?path=(.*?)|i', $line)) {
	                           $line=str_replace('cpuindex.php', 'index.php', $line);
	                        	$close_site=0;
							}elseif (preg_match('|(.*?) cpuindex.php\?path=(.*?)|i', $line)) {
                                $close_site=0;
							}
						}
					file_put_contents(CURRENT_WORKING_DIR.'/.htaccess', $content);
					$regedit->setVar("//numpages/numpages", $numpages);
				}

				$this->chooseRedirect();
			}

			$params['numpages']['boolean:numpages'] = $regedit->getVal("//numpages/numpages");

			$this->setDataType("settings");
			$this->setActionType("modify");

			$data = $this->prepareData($params, "settings");

			$this->setData($data);
			$this->doData();
        }
    }
?>