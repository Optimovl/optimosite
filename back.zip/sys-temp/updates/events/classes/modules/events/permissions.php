<?php
	$permissions = array(
		'events' => array('feed', 'last', 'getUserSettings', 'saveSettings', 'getUser', 'markUnreadEvents', 'markReadEvents')
	);
?>