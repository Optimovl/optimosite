<?php
$C_LANG = Array();

$C_LANG['module_name'] = "events";
$C_LANG['module_title'] = "events";

$C_LANG['events'] = "events";


$LANG_EXPORT = array();
?>
