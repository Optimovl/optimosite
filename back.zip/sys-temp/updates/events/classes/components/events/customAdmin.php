<?php

	/** Класс пользовательских методов административной панели */
	class EventsCustomAdmin {

		/** @var events $module */
		public $module;

	}
