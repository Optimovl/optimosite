<?php

	/** Класс пользовательских макросов */
	class EventsCustomMacros {

		/** @var events $module */
		public $module;
	}
