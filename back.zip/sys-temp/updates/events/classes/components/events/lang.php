<?php

	/** Языковые константы для русской версии */
	$C_LANG = [];
	$C_LANG['module_name'] = 'events';
	$C_LANG['module_title'] = 'events';
	$C_LANG['events'] = 'events';

	$LANG_EXPORT = [];

