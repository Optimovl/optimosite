<?php
	abstract class __stat_custom {
		//TODO: Write here your own macroses
	};
?>
