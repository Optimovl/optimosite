<?php

	/** Класс пользовательских методов административной панели */
	class StatCustomAdmin {

		/** @var stat $module */
		public $module;

	}
