<?php

	/** Класс пользовательских макросов */
	class NewsCustomMacros {

		/** @var news $module */
		public $module;
	}
