<?php

	/** Класс пользовательских методов административной панели */
	class NewsCustomAdmin {

		/** @var news $module */
		public $module;
	}
