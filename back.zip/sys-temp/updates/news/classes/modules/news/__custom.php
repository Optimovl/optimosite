<?php
	abstract class __custom_news {
		//TODO: Write here your own macroses
	};
?>