<?php
	abstract class __custom_adm_news {
		//TODO: Write here your own macroses (admin mode) р
	};
?>