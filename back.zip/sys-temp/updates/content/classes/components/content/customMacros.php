<?php

	/** Класс пользовательских макросов */
	class ContentCustomMacros {

		/** @var content $module */
		public $module;
	}
