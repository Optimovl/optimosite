<?php

	/** Класс пользовательских методов административной панели */
	class ContentCustomAdmin {

		/** @var content $module */
		public $module;

	}
