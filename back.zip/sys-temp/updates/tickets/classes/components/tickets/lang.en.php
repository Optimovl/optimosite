<?php

	/** Языковые константы для английской версии */
	$C_LANG = [];
	$C_LANG['module_name'] = 'Notes';

