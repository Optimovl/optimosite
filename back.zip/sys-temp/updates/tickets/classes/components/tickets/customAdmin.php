<?php

	/** Класс пользовательских методов административной панели */
	class TicketsCustomAdmin {

		/** @var tickets $module */
		public $module;

	}
