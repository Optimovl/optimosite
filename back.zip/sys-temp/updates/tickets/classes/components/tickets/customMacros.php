<?php

	/** Класс пользовательских макросов */
	class TicketsCustomMacros {

		/** @var tickets $module */
		public $module;
	}
