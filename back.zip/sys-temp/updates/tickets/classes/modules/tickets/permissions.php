<?php
	$permissions = array(
		'tickets' => array(
			'tickets', 'delTicket', 'manage'
		)
	);
?>
