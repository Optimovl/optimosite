<?php
	$i18n = Array(
		'module-tickets' => 'Заметки',
		'header-tickets-tickets' => 'Управление заметками',
		'perms-tickets-tickets' => 'Управление заметками',
		'wrong-permissions-json' => 'Редактировать или удалять заметки могут только их владельцы или супервайзеры',
		'ticket-not-found-json' => 'Заметка не найдена'
	);
?>
