<?php
	$i18n = Array(
		'module-tickets' => 'Notes',
		'header-tickets-tickets' => 'Notes management',
		'perms-tickets-tickets' => 'Notes management',
		'wrong-permissions-json' => 'Only owners of tickets or superusers can edit or remove them',
		'ticket-not-found-json' => 'Ticket is not found'
	);
?>
