<?php
	$C_LANG = array();
	$C_LANG['module_name'] = "Заметки";
?>